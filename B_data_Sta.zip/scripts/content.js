console.log('Content script 已加载');

function getVideoStats() {
    console.log('开始获取视频统计数据');
    
    try {
        const statsData = {
            title: document.querySelector('h1.video-title')?.textContent.trim(),
            playCount: document.querySelector('.view.item')?.textContent.trim(),
            likeCount: document.querySelector('.video-like-info.video-toolbar-item-text')?.textContent.trim(),
            coinCount: document.querySelector('.video-coin-info.video-toolbar-item-text')?.textContent.trim(),
            favoriteCount: document.querySelector('.video-fav-info.video-toolbar-item-text')?.textContent.trim(),
            shareCount: document.querySelector('.video-share-info.video-toolbar-item-text')?.textContent.trim()
        };

        console.log('获取到的统计数据:', statsData);

        // 检查数据是否完整
        const missingData = Object.entries(statsData)
            .filter(([key, value]) => !value)
            .map(([key]) => key);
            
        if (missingData.length > 0) {
            console.warn('以下数据未获取到:', missingData);
        }

        chrome.runtime.sendMessage({ type: 'VIDEO_STATS', data: statsData }, response => {
            console.log('消息发送结果:', response);
        });
    } catch (error) {
        console.error('获取数据时出错:', error);
    }
}

// 页面加载完成后执行
document.addEventListener('DOMContentLoaded', () => {
    console.log('页面加载完成，等待2秒后获取数据');
    setTimeout(getVideoStats, 3000);
});

// 监听数据更新
const observer = new MutationObserver(() => {
    console.log('检测到页面数据更新');
    getVideoStats();
});

// 等待DOM加载完成后再设置观察器
window.addEventListener('load', () => {
    const videoDataElement = document.querySelector('.video-toolbar-left');
    if (videoDataElement) {
        console.log('成功找到视频数据区域，开始观察');
        observer.observe(videoDataElement, {
            childList: true,
            subtree: true,
            characterData: true
        });
    } else {
        console.error('未找到视频数据区域');
    }
});

// 监听来自popup的消息
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    console.log('Content script收到消息:', message);
    if (message.type === 'GET_STATS') {
        try {
            getVideoStats();
            sendResponse({status: 'success'});
        } catch (error) {
            console.error('处理GET_STATS消息时出错:', error);
            sendResponse({status: 'error', error: error.message});
        }
    }
    return true; // 保持消息通道开启
}); 