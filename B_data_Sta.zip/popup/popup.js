// 更新统计数据显示
function updateStats(stats) {
    console.log('更新统计数据:', stats);
    try {
        document.getElementById('videoTitle').textContent = stats.title || '-';
        document.getElementById('playCount').textContent = stats.playCount || '-';
        document.getElementById('likeCount').textContent = stats.likeCount || '-';
        document.getElementById('coinCount').textContent = stats.coinCount || '-';
        document.getElementById('favoriteCount').textContent = stats.favoriteCount || '-';
        document.getElementById('shareCount').textContent = stats.shareCount || '-';
    } catch (error) {
        console.error('更新统计数据时出错:', error);
    }
}

// 注入content script
async function injectContentScript(tabId) {
    try {
        await chrome.scripting.executeScript({
            target: { tabId },
            files: ['scripts/content.js']
        });
        console.log('Content script 注入成功');
        return true;
    } catch (error) {
        console.error('注入content script失败:', error);
        return false;
    }
}

// 获取视频统计数据
async function getVideoStats(tabId) {
    return new Promise((resolve) => {
        chrome.tabs.sendMessage(tabId, { type: 'GET_STATS' }, response => {
            if (chrome.runtime.lastError) {
                console.warn('发送消息失败:', chrome.runtime.lastError);
                resolve(null);
            } else {
                resolve(response);
            }
        });
    });
}

// 监听来自 content script 的消息
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    console.log('Popup收到消息:', message);
    if (message.type === 'VIDEO_STATS') {
        updateStats(message.data);
        sendResponse({status: 'received'});
    }
});

// 初始化
window.addEventListener('DOMContentLoaded', async () => {
    console.log('Popup页面加载完成');
    
    try {
        const tabs = await chrome.tabs.query({active: true, currentWindow: true});
        const currentTab = tabs[0];
        console.log('当前标签页:', currentTab);

        if (currentTab?.url?.includes('bilibili.com/video')) {
            console.log('当前是B站视频页面');
            
            // 尝试获取数据
            let response = await getVideoStats(currentTab.id);
            
            // 如果失败，尝试注入content script后重试
            if (!response) {
                console.log('首次获取失败，尝试注入content script');
                await injectContentScript(currentTab.id);
                
                // 等待content script初始化
                await new Promise(resolve => setTimeout(resolve, 500));
                
                // 重试获取数据
                response = await getVideoStats(currentTab.id);
            }
            
            if (!response) {
                document.querySelector('.container').innerHTML = 
                    '<p style="text-align: center; color: #666;">无法获取数据，请刷新页面重试</p>';
            }
        } else {
            console.log('当前页面不是B站视频页面');
            document.querySelector('.container').innerHTML = 
                '<p style="text-align: center; color: #666;">请在B站视频页面使用此插件</p>';
        }
    } catch (error) {
        console.error('初始化失败:', error);
        document.querySelector('.container').innerHTML = 
            '<p style="text-align: center; color: #666;">发生错误，请刷新页面重试</p>';
    }
}); 